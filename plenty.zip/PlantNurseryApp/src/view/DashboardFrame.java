package view;

import dao.PlantDAO;
import model.Plant;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class DashboardFrame extends JFrame {
    private JTextField txtName, txtCategory, txtPrice, txtStock, txtId;
    private JTable table;
    private DefaultTableModel tableModel;
    private PlantDAO plantDAO;

    // Modern Professional Color Palette
    private final Color PRIMARY_COLOR = new Color(27, 94, 32);     // Rich Dark Green
    private final Color SECONDARY_COLOR = new Color(56, 142, 60);   // Leaf Green
    private final Color BG_COLOR = new Color(245, 247, 248);          // Light Grayish Background
    private final Color CARD_BG = new Color(255, 255, 255);           // Pure White
    private final Color TEXT_DARK = new Color(47, 79, 79);            // Dark Slate Gray

    public DashboardFrame() {
        plantDAO = new PlantDAO();
        setTitle("🌱 Smart Plant Nursery & Inventory Control System");
        setSize(1100, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main Root Panel
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(mainPanel);

        // ================= TOP HEADER BANNER =================
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, PRIMARY_COLOR, getWidth(), getHeight(), SECONDARY_COLOR);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setPreferredSize(new Dimension(0, 70));
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel lblTitle = new JLabel("🌿 Plant Nursery Inventory Dashboard");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        
        JLabel lblSubTitle = new JLabel("System Management Panel");
        lblSubTitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubTitle.setForeground(new Color(220, 237, 200));

        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(lblSubTitle, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // ================= CENTER CONTENT CONTAINER (Table + Form) =================
        JPanel contentContainer = new JPanel(new BorderLayout(15, 0));
        contentContainer.setOpaque(false);
        mainPanel.add(contentContainer, BorderLayout.CENTER);

        // --- LEFT SIDE: TABLE PANEL ---
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(CARD_BG);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(218, 224, 221), 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        JLabel lblTableTitle = new JLabel("📋 Registered Plants List");
        lblTableTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTableTitle.setForeground(PRIMARY_COLOR);
        lblTableTitle.setBorder(new EmptyBorder(0, 0, 10, 0));
        tablePanel.add(lblTableTitle, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID", "Plant Name", "Category", "Price (BDT)", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setSelectionBackground(new Color(200, 230, 201));
        table.setSelectionForeground(Color.BLACK);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(SECONDARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.setShowGrid(true);
        table.setGridColor(new Color(230, 230, 230));

        // Center align table text
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(224, 224, 224)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        contentContainer.add(tablePanel, BorderLayout.CENTER);

        // --- RIGHT SIDE: FORM & BUTTONS PANEL ---
        JPanel rightPanel = new JPanel(new BorderLayout(0, 10));
        rightPanel.setOpaque(false);
        rightPanel.setPreferredSize(new Dimension(320, 0));

        // Form Inputs Card
        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(218, 224, 221), 1),
                new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;

        JLabel lblFormTitle = new JLabel("📝 Plant Details Form");
        lblFormTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblFormTitle.setForeground(PRIMARY_COLOR);
        formCard.add(lblFormTitle, gbc);

        // Fields
        gbc.gridwidth = 1;
        gbc.gridy++; addFormRow(formCard, gbc, "Plant ID:", txtId = createTextField(false));
        gbc.gridy++; addFormRow(formCard, gbc, "Plant Name:", txtName = createTextField(true));
        gbc.gridy++; addFormRow(formCard, gbc, "Category:", txtCategory = createTextField(true));
        gbc.gridy++; addFormRow(formCard, gbc, "Price (BDT):", txtPrice = createTextField(true));
        gbc.gridy++; addFormRow(formCard, gbc, "Stock Qty:", txtStock = createTextField(true));

        rightPanel.add(formCard, BorderLayout.CENTER);

        // Action Buttons Card (Stacked neatly at bottom right)
        JPanel buttonCard = new JPanel(new GridLayout(2, 2, 8, 8));
        buttonCard.setOpaque(false);
        buttonCard.setBorder(new EmptyBorder(5, 0, 0, 0));

        JButton btnAdd = createStyledButton("➕ Add Plant", new Color(46, 125, 50));
        JButton btnUpdate = createStyledButton("✏️ Update", new Color(21, 101, 192));
        JButton btnDelete = createStyledButton("🗑️ Delete", new Color(198, 40, 40));
        JButton btnClear = createStyledButton("🧹 Clear", new Color(97, 97, 97));

        buttonCard.add(btnAdd);
        buttonCard.add(btnUpdate);
        buttonCard.add(btnDelete);
        buttonCard.add(btnClear);

        rightPanel.add(buttonCard, BorderLayout.SOUTH);
        contentContainer.add(rightPanel, BorderLayout.EAST);

        // Load Initial Data
        loadTableData();

        // ================= EVENTS =================
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    txtId.setText(tableModel.getValueAt(row, 0).toString());
                    txtName.setText(tableModel.getValueAt(row, 1).toString());
                    txtCategory.setText(tableModel.getValueAt(row, 2).toString());
                    txtPrice.setText(tableModel.getValueAt(row, 3).toString());
                    txtStock.setText(tableModel.getValueAt(row, 4).toString());
                }
            }
        });

        btnAdd.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                String category = txtCategory.getText().trim();
                if(name.isEmpty() || category.isEmpty()) {
                    showWarning("Please fill in all required fields!");
                    return;
                }
                double price = Double.parseDouble(txtPrice.getText());
                int stock = Integer.parseInt(txtStock.getText());

                Plant plant = new Plant(name, category, price, stock);
                if (plantDAO.addPlant(plant)) {
                    showSuccess("Plant Added Successfully! 🌱");
                    loadTableData();
                    clearForm();
                } else {
                    showError("Failed to add plant to database.");
                }
            } catch (Exception ex) {
                showError("Please enter valid numeric values for Price and Stock!");
            }
        });

        btnUpdate.addActionListener(e -> {
            try {
                if(txtId.getText().isEmpty()) {
                    showWarning("Please select a plant from the table first!");
                    return;
                }
                int id = Integer.parseInt(txtId.getText());
                String name = txtName.getText().trim();
                String category = txtCategory.getText().trim();
                double price = Double.parseDouble(txtPrice.getText());
                int stock = Integer.parseInt(txtStock.getText());

                Plant plant = new Plant(id, name, category, price, stock);
                if (plantDAO.updatePlant(plant)) {
                    showSuccess("Plant Updated Successfully!");
                    loadTableData();
                    clearForm();
                } else {
                    showError("Failed to update record.");
                }
            } catch (Exception ex) {
                showError("Please check your input values!");
            }
        });

        btnDelete.addActionListener(e -> {
            try {
                if(txtId.getText().isEmpty()) {
                    showWarning("Please select a plant from the table to delete!");
                    return;
                }
                int id = Integer.parseInt(txtId.getText());
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this plant?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (plantDAO.deletePlant(id)) {
                        showSuccess("Plant Deleted Successfully!");
                        loadTableData();
                        clearForm();
                    } else {
                        showError("Failed to delete record.");
                    }
                }
            } catch (Exception ex) {
                showError("Invalid selection for deletion.");
            }
        });

        btnClear.addActionListener(e -> clearForm());
    }

    // Helper method to add form rows cleanly
    private void addFormRow(JPanel panel, GridBagConstraints gbc, String labelText, JTextField textField) {
        gbc.gridx = 0; gbc.weightx = 0.3;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(TEXT_DARK);
        panel.add(label, gbc);

        gbc.gridx = 1; gbc.weightx = 0.7;
        panel.add(textField, gbc);
    }

    private JTextField createTextField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setEditable(editable);
        tf.setPreferredSize(new Dimension(0, 28));
        if(!editable) {
            tf.setBackground(new Color(240, 240, 240));
        }
        return tf;
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        return btn;
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Plant> list = plantDAO.getAllPlants();
        for (Plant p : list) {
            tableModel.addRow(new Object[]{p.getId(), p.getName(), p.getCategory(), p.getPrice(), p.getStock()});
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtCategory.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        table.clearSelection();
    }

    private void showSuccess(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new DashboardFrame().setVisible(true));
    }
}