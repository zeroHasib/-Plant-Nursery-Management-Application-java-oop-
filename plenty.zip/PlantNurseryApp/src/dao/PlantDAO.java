package dao;

import database.DatabaseConnection;
import model.Plant;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlantDAO {

    // Insert Operation
    public boolean addPlant(Plant plant) {
        String query = "INSERT INTO plants (name, category, price, stock) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, plant.getName());
            pst.setString(2, plant.getCategory());
            pst.setDouble(3, plant.getPrice());
            pst.setInt(4, plant.getStock());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Read Operation (Fetch all plants)
    public List<Plant> getAllPlants() {
        List<Plant> list = new ArrayList<>();
        String query = "SELECT * FROM plants";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                Plant plant = new Plant(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getDouble("price"),
                    rs.getInt("stock")
                );
                list.add(plant);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Update Operation
    public boolean updatePlant(Plant plant) {
        String query = "UPDATE plants SET name=?, category=?, price=?, stock=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, plant.getName());
            pst.setString(2, plant.getCategory());
            pst.setDouble(3, plant.getPrice());
            pst.setInt(4, plant.getStock());
            pst.setInt(5, plant.getId());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete Operation
    public boolean deletePlant(int id) {
        String query = "DELETE FROM plants WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}