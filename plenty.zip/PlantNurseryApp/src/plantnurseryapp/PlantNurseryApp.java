package plantnurseryapp; // NetBeans auto je package baniyeche seta thakbe

import view.DashboardFrame;
import javax.swing.SwingUtilities;

public class PlantNurseryApp {
    public static void main(String[] args) {
        // DashboardFrame-ke launch korar jonno
        SwingUtilities.invokeLater(() -> {
            new DashboardFrame().setVisible(true);
        });
    }
}